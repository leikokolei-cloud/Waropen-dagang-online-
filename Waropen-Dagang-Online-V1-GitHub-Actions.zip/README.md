# Waropen Dagang Online V1

Marketplace Android sederhana untuk jual-beli produk.

## Fitur V1
- Beranda produk
- Mode penjual: tambah produk
- Tombol pesan melalui WhatsApp
- Struktur project Android siap dikembangkan
- Application ID: com.waropen.dagangonline

## Build
Buka project ini di Android Studio/AndroidIDE, tunggu Gradle sync, lalu Build APK.
Untuk Google Play Store, gunakan Build > Generate Signed App Bundle (.aab) dan buat release keystore.
