package com.waropen.dagangonline

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Product(val name:String, val price:String)

class MainActivity : AppCompatActivity() {
    private val products = mutableListOf(
        Product("Dress Cendrawasih", "Rp250.000"),
        Product("Noken Papua", "Rp150.000"),
        Product("Kerajinan Papua", "Rp100.000")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24,24,24,24)
        }
        val title = TextView(this).apply {
            text = "Waropen Dagang Online"
            textSize = 26f
            setPadding(0,0,0,20)
        }
        root.addView(title)
        val login = Button(this).apply { text = "Login / Daftar" }
        root.addView(login)
        val seller = Button(this).apply { text = "Mode Penjual - Tambah Produk" }
        root.addView(seller)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        products.forEach { p ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0,14,0,14)
            }
            val name = TextView(this).apply { text = p.name; textSize = 20f }
            val price = TextView(this).apply { text = p.price; textSize = 17f }
            val buy = Button(this).apply { text = "Pesan via WhatsApp" }
            buy.setOnClickListener {
                val msg = Uri.encode("Halo, saya ingin memesan ${p.name} dengan harga ${p.price}.")
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/?text=$msg")))
            }
            card.addView(name); card.addView(price); card.addView(buy)
            list.addView(card)
        }
        root.addView(list)
        setContentView(root)

        login.setOnClickListener {
            Toast.makeText(this, "Fitur login siap dikembangkan pada versi berikutnya.", Toast.LENGTH_SHORT).show()
        }
        seller.setOnClickListener {
            val input = EditText(this).apply { hint = "Nama produk" }
            AlertDialog.Builder(this)
                .setTitle("Tambah Produk")
                .setView(input)
                .setPositiveButton("Tambah") { _, _ ->
                    if (input.text.isNotBlank()) {
                        products.add(Product(input.text.toString(), "Harga belum diatur"))
                        showHome()
                    }
                }
                .setNegativeButton("Batal", null).show()
        }
    }
}
